import './bootstrap';
import feather from 'feather-icons';

document.addEventListener('DOMContentLoaded', function() {
    feather.replace();
});